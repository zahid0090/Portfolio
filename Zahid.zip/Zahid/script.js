function toggleMode(){
  document.body.classList.toggle("light-mode");
}

const text="Professional Web Designer & Developer";
let i=0;

function typing(){
  if(i<text.length){
    document.getElementById("typing").innerHTML+=text.charAt(i);
    i++;
    setTimeout(typing,70);
  }
}
typing();

window.addEventListener("scroll", ()=>{
  const skills=document.querySelectorAll(".bar div");
  const trigger=window.innerHeight;

  skills.forEach(bar=>{
    const top=bar.getBoundingClientRect().top;
    if(top < trigger-50){
      bar.style.width=bar.getAttribute("style").split(":")[1];
    }
  });
});